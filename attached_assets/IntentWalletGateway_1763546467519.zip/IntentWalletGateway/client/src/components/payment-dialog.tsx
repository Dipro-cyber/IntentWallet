import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle2, Loader2, AlertCircle, ExternalLink } from "lucide-react";
import { Intent, Payment } from "@shared/schema";
import { useWeb3 } from "@/contexts/Web3Context";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { generateMockTxHash } from "@/lib/web3";

interface PaymentDialogProps {
  open: boolean;
  onClose: () => void;
  intent: Intent;
  onPaymentComplete: () => void;
}

type PaymentStep = "authorize" | "processing" | "confirming" | "completed" | "failed";

export function PaymentDialog({ open, onClose, intent, onPaymentComplete }: PaymentDialogProps) {
  const { address } = useWeb3();
  const [paymentStep, setPaymentStep] = useState<PaymentStep>("authorize");
  const [txHash, setTxHash] = useState<string>("");

  const processPaymentMutation = useMutation({
    mutationFn: async () => {
      // Step 1: Create payment record
      const payment = await apiRequest<Payment>('POST', '/api/payments', {
        intentId: intent.id,
        userAddress: address!,
        amount: intent.estimatedCost || "0.50",
        currency: "USDC",
        paymentStatus: "pending",
      });

      setPaymentStep("processing");
      
      // Simulate transaction
      await new Promise(resolve => setTimeout(resolve, 2000));
      const mockTxHash = generateMockTxHash();
      setTxHash(mockTxHash);

      setPaymentStep("confirming");
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Step 2: Confirm payment
      await apiRequest('PATCH', `/api/payments/${payment.id}/confirm`, {
        txHash: mockTxHash,
        blockNumber: Math.floor(Math.random() * 1000000).toString(),
        gasUsed: "21000",
        proofHash: generateMockTxHash(),
      });

      setPaymentStep("completed");
      return payment;
    },
    onError: () => {
      setPaymentStep("failed");
    },
  });

  const handleAuthorize = () => {
    processPaymentMutation.mutate();
  };

  const handleComplete = () => {
    onPaymentComplete();
    onClose();
    setPaymentStep("authorize");
    setTxHash("");
  };

  const cost = intent.estimatedCost || "0.50";
  const gasEstimate = "0.0002";
  const total = (parseFloat(cost) + parseFloat(gasEstimate)).toFixed(4);

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && paymentStep === "authorize" && onClose()}>
      <DialogContent className="max-w-md" data-testid="dialog-payment">
        <DialogHeader>
          <DialogTitle>HTTP 402 Payment Required</DialogTitle>
          <DialogDescription>
            Complete payment to unlock API access and execute your intent
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Cost Breakdown */}
          <div className="bg-muted rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Intent Type</span>
              <Badge variant="secondary">
                {intent.intentType || 'API Call'}
              </Badge>
            </div>
            <Separator />
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">API Endpoint Cost</span>
                <span className="font-mono font-semibold">{cost} USDC</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Estimated Gas</span>
                <span className="font-mono">{gasEstimate} ETH</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="font-medium">Total Payment</span>
                <span className="text-lg font-semibold font-mono text-primary">
                  {total} USDC
                </span>
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary text-primary-foreground rounded flex items-center justify-center text-xs font-semibold">
                  MM
                </div>
                <div>
                  <div className="text-sm font-medium">MetaMask Wallet</div>
                  <div className="text-xs text-muted-foreground font-mono">
                    {address?.slice(0, 10)}...{address?.slice(-8)}
                  </div>
                </div>
              </div>
              <Badge variant="outline">Selected</Badge>
            </div>
          </div>

          {/* Status Display */}
          {paymentStep !== "authorize" && (
            <div className="bg-muted rounded-lg p-4">
              {paymentStep === "processing" && (
                <div className="flex items-center gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <div>
                    <div className="font-medium">Processing Payment...</div>
                    <div className="text-sm text-muted-foreground">
                      Awaiting transaction confirmation
                    </div>
                  </div>
                </div>
              )}

              {paymentStep === "confirming" && (
                <div className="flex items-center gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <div className="flex-1">
                    <div className="font-medium">Confirming on Base L2...</div>
                    <div className="text-sm text-muted-foreground">
                      Validating on-chain proof
                    </div>
                  </div>
                </div>
              )}

              {paymentStep === "completed" && (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <div>
                      <div className="font-medium text-green-600 dark:text-green-400">
                        Payment Confirmed!
                      </div>
                      <div className="text-sm text-muted-foreground">
                        API access unlocked
                      </div>
                    </div>
                  </div>
                  {txHash && (
                    <a
                      href={`https://basescan.org/tx/${txHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-primary hover-elevate p-2 rounded-md"
                      data-testid="link-view-transaction"
                    >
                      <span className="font-mono text-xs">{txHash.slice(0, 20)}...</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              )}

              {paymentStep === "failed" && (
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-5 w-5 text-destructive" />
                  <div>
                    <div className="font-medium text-destructive">Payment Failed</div>
                    <div className="text-sm text-muted-foreground">
                      Please try again or contact support
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            {paymentStep === "authorize" && (
              <>
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="flex-1"
                  data-testid="button-cancel-payment"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleAuthorize}
                  className="flex-1"
                  data-testid="button-authorize-payment"
                >
                  Authorize Payment
                </Button>
              </>
            )}

            {paymentStep === "completed" && (
              <Button onClick={handleComplete} className="w-full" data-testid="button-complete">
                Complete
              </Button>
            )}

            {paymentStep === "failed" && (
              <>
                <Button variant="outline" onClick={onClose} className="flex-1">
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setPaymentStep("authorize");
                    processPaymentMutation.reset();
                  }}
                  className="flex-1"
                >
                  Retry
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
