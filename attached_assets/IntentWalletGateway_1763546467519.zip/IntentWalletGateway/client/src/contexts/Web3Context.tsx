import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { connectWallet, getBalance, hasMetaMask, formatAddress, WalletState } from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';

interface Web3ContextType extends WalletState {
  connect: () => Promise<void>;
  disconnect: () => void;
  formattedAddress: string;
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

export function Web3Provider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [walletState, setWalletState] = useState<WalletState>({
    address: null,
    balance: null,
    chainId: null,
    isConnecting: false,
    error: null,
  });

  const connect = async () => {
    if (!hasMetaMask()) {
      toast({
        title: "MetaMask Not Found",
        description: "Please install MetaMask to use this application.",
        variant: "destructive",
      });
      return;
    }

    setWalletState(prev => ({ ...prev, isConnecting: true, error: null }));

    try {
      const { address, chainId } = await connectWallet();
      const balance = await getBalance(address);
      
      setWalletState({
        address,
        balance,
        chainId,
        isConnecting: false,
        error: null,
      });

      toast({
        title: "Wallet Connected",
        description: `Connected to ${formatAddress(address)}`,
      });

      // Store in localStorage
      localStorage.setItem('walletConnected', 'true');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to connect wallet';
      setWalletState(prev => ({
        ...prev,
        isConnecting: false,
        error: errorMessage,
      }));

      toast({
        title: "Connection Failed",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const disconnect = () => {
    setWalletState({
      address: null,
      balance: null,
      chainId: null,
      isConnecting: false,
      error: null,
    });
    localStorage.removeItem('walletConnected');

    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected.",
    });
  };

  // Auto-connect on mount if previously connected
  useEffect(() => {
    const wasConnected = localStorage.getItem('walletConnected');
    if (wasConnected === 'true' && hasMetaMask()) {
      connect();
    }
  }, []);

  // Listen for account changes
  useEffect(() => {
    if (!window.ethereum) return;

    const handleAccountsChanged = (accounts: unknown) => {
      if (Array.isArray(accounts) && accounts.length === 0) {
        disconnect();
      } else if (Array.isArray(accounts) && typeof accounts[0] === 'string') {
        setWalletState(prev => ({ ...prev, address: accounts[0] }));
        getBalance(accounts[0]).then(balance => {
          setWalletState(prev => ({ ...prev, balance }));
        });
      }
    };

    const handleChainChanged = () => {
      window.location.reload();
    };

    window.ethereum.on('accountsChanged', handleAccountsChanged);
    window.ethereum.on('chainChanged', handleChainChanged);

    return () => {
      window.ethereum?.removeListener('accountsChanged', handleAccountsChanged);
      window.ethereum?.removeListener('chainChanged', handleChainChanged);
    };
  }, []);

  return (
    <Web3Context.Provider
      value={{
        ...walletState,
        connect,
        disconnect,
        formattedAddress: formatAddress(walletState.address),
      }}
    >
      {children}
    </Web3Context.Provider>
  );
}

export function useWeb3() {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}
