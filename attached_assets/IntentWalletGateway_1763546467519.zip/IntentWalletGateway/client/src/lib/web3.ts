import { BrowserProvider, Contract, formatEther, parseUnits } from 'ethers';

export interface WalletState {
  address: string | null;
  balance: string | null;
  chainId: number | null;
  isConnecting: boolean;
  error: string | null;
}

// Base L2 Chain ID (8453 for mainnet, 84532 for testnet)
export const BASE_CHAIN_ID = 8453;
export const BASE_TESTNET_CHAIN_ID = 84532;

// Check if MetaMask is installed
export function hasMetaMask(): boolean {
  return typeof window !== 'undefined' && typeof window.ethereum !== 'undefined';
}

// Connect to MetaMask
export async function connectWallet(): Promise<{ address: string; chainId: number }> {
  if (!hasMetaMask()) {
    throw new Error('MetaMask is not installed. Please install MetaMask to continue.');
  }

  try {
    const provider = new BrowserProvider(window.ethereum);
    const accounts = await provider.send('eth_requestAccounts', []);
    const network = await provider.getNetwork();
    
    return {
      address: accounts[0],
      chainId: Number(network.chainId),
    };
  } catch (error: unknown) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 4001) {
      throw new Error('User rejected connection request');
    }
    throw new Error('Failed to connect wallet');
  }
}

// Get wallet balance
export async function getBalance(address: string): Promise<string> {
  if (!hasMetaMask()) return '0';
  
  try {
    const provider = new BrowserProvider(window.ethereum);
    const balance = await provider.getBalance(address);
    return formatEther(balance);
  } catch (error) {
    console.error('Failed to get balance:', error);
    return '0';
  }
}

// Switch to Base network
export async function switchToBase(): Promise<void> {
  if (!hasMetaMask()) {
    throw new Error('MetaMask is not installed');
  }

  try {
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: `0x${BASE_CHAIN_ID.toString(16)}` }],
    });
  } catch (error: unknown) {
    // This error code indicates that the chain has not been added to MetaMask
    if (error && typeof error === 'object' && 'code' in error && error.code === 4902) {
      await addBaseNetwork();
    } else {
      throw error;
    }
  }
}

// Add Base network to MetaMask
export async function addBaseNetwork(): Promise<void> {
  if (!hasMetaMask()) {
    throw new Error('MetaMask is not installed');
  }

  await window.ethereum.request({
    method: 'wallet_addEthereumChain',
    params: [
      {
        chainId: `0x${BASE_CHAIN_ID.toString(16)}`,
        chainName: 'Base',
        nativeCurrency: {
          name: 'Ethereum',
          symbol: 'ETH',
          decimals: 18,
        },
        rpcUrls: ['https://mainnet.base.org'],
        blockExplorerUrls: ['https://basescan.org'],
      },
    ],
  });
}

// Format address for display (0x1234...5678)
export function formatAddress(address: string | null): string {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

// Generate mock transaction hash
export function generateMockTxHash(): string {
  return '0x' + Array.from({ length: 64 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
}

// TypeScript declarations for window.ethereum
declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
      on: (event: string, callback: (...args: unknown[]) => void) => void;
      removeListener: (event: string, callback: (...args: unknown[]) => void) => void;
    };
  }
}
