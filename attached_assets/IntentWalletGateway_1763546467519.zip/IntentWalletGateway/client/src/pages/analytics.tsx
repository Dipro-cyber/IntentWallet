import { useQuery } from "@tanstack/react-query";
import { useWeb3 } from "@/contexts/Web3Context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, Activity, TrendingUp, Clock } from "lucide-react";
import { Intent, Payment } from "@shared/schema";
import { formatDistance } from "date-fns";

interface AnalyticsData {
  intents: Intent[];
  payments: Payment[];
  recentActivity: Array<{
    type: "intent" | "payment";
    timestamp: Date;
    description: string;
  }>;
}

export default function Analytics() {
  const { address } = useWeb3();

  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics', address],
    enabled: !!address,
  });

  if (!address) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="max-w-md text-center space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
            <BarChart3 className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold">Connect Wallet</h2>
          <p className="text-muted-foreground">
            Connect your wallet to view detailed analytics and insights about your activity.
          </p>
        </div>
      </div>
    );
  }

  const totalSpent = analytics?.payments.reduce(
    (sum, p) => sum + parseFloat(p.amount || "0"),
    0
  ).toFixed(2) || "0.00";

  const avgCostPerIntent = analytics?.intents.length
    ? (parseFloat(totalSpent) / analytics.intents.length).toFixed(2)
    : "0.00";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Analytics</h1>
        <p className="text-muted-foreground">
          Detailed insights into your intent execution and API usage patterns
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-semibold">
                  {analytics?.intents.length || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Intents executed
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Cost</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-semibold font-mono">
                  {avgCostPerIntent} <span className="text-lg">USDC</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Per intent
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-semibold">
                  {analytics?.intents.length
                    ? Math.round(
                        (analytics.intents.filter((i) => i.status === "confirmed").length /
                          analytics.intents.length) *
                          100
                      )
                    : 0}
                  %
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Confirmed transactions
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            <CardTitle>Recent Activity</CardTitle>
          </div>
          <CardDescription>
            Your latest intent executions and API access records
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : !analytics?.intents.length ? (
            <div className="text-center py-8 text-muted-foreground">
              No activity yet. Start by creating your first intent.
            </div>
          ) : (
            <div className="space-y-4">
              {analytics.intents.slice(0, 5).map((intent) => (
                <div
                  key={intent.id}
                  className="flex items-start gap-4 p-3 rounded-lg border hover-elevate"
                >
                  <div className="flex items-center justify-center w-10 h-10 bg-primary/10 text-primary rounded-lg flex-shrink-0">
                    <Activity className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium line-clamp-1">{intent.rawIntent}</div>
                    <div className="text-sm text-muted-foreground">
                      {intent.createdAt
                        ? formatDistance(new Date(intent.createdAt), new Date(), {
                            addSuffix: true,
                          })
                        : 'Recently'}
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="font-mono font-semibold text-sm">
                      {intent.estimatedCost || '0.00'} USDC
                    </div>
                    <div className="text-xs text-muted-foreground capitalize">
                      {intent.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Usage Patterns */}
      <Card>
        <CardHeader>
          <CardTitle>Usage Patterns</CardTitle>
          <CardDescription>
            Breakdown of your API usage by category
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {['swap', 'nft_query', 'price_oracle', 'defi_action'].map((type) => {
              const count =
                analytics?.intents.filter((i) => i.intentType === type).length || 0;
              const total = analytics?.intents.length || 1;
              const percentage = Math.round((count / total) * 100);

              return (
                <div key={type} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="capitalize">{type.replace('_', ' ')}</span>
                    <span className="font-mono font-semibold">
                      {count} ({percentage}%)
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
