import { useState } from "react";
import { useWeb3 } from "@/contexts/Web3Context";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Key, Package, TrendingUp, Zap, ArrowRight } from "lucide-react";
import { mockApiEndpoints, ApiEndpoint } from "@shared/schema";

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "nft":
      return Package;
    case "defi":
      return TrendingUp;
    case "oracle":
      return Zap;
    case "analytics":
      return Key;
    default:
      return Key;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case "nft":
      return "text-purple-500";
    case "defi":
      return "text-green-500";
    case "oracle":
      return "text-blue-500";
    case "analytics":
      return "text-orange-500";
    default:
      return "text-muted-foreground";
  }
};

export default function APIAccess() {
  const { address } = useWeb3();
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint | null>(null);

  if (!address) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="max-w-md text-center space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
            <Key className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold">Connect Wallet</h2>
          <p className="text-muted-foreground">
            Connect your wallet to browse and unlock API endpoints with HTTP 402 payments.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-semibold mb-2">API Access</h1>
        <p className="text-muted-foreground">
          Browse available API endpoints and unlock access with instant USDC payments
        </p>
      </div>

      {/* API Endpoints Grid */}
      <div className="grid gap-4 md:grid-cols-2">
        {mockApiEndpoints.map((endpoint) => {
          const Icon = getCategoryIcon(endpoint.category);
          const colorClass = getCategoryColor(endpoint.category);

          return (
            <Card key={endpoint.id} className="hover-elevate transition-all" data-testid={`api-card-${endpoint.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`h-5 w-5 ${colorClass}`} />
                      <CardTitle className="text-lg">{endpoint.name}</CardTitle>
                    </div>
                    <CardDescription>{endpoint.description}</CardDescription>
                  </div>
                  <Badge variant="secondary" className="capitalize">
                    {endpoint.category}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-muted-foreground">Cost per call</div>
                    <div className="text-2xl font-semibold font-mono text-primary">
                      {endpoint.costPerCall} USDC
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedEndpoint(endpoint)}
                    className="gap-2"
                    data-testid={`button-unlock-${endpoint.id}`}
                  >
                    Unlock Access
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* How It Works */}
      <Card>
        <CardHeader>
          <CardTitle>How HTTP 402 Payments Work</CardTitle>
          <CardDescription>
            Pay-per-use API access on Base L2 with instant unlocking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-lg mb-3">
                <span className="text-xl font-bold">1</span>
              </div>
              <h3 className="font-semibold">Select Endpoint</h3>
              <p className="text-sm text-muted-foreground">
                Choose the API you want to access from our curated catalog
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-lg mb-3">
                <span className="text-xl font-bold">2</span>
              </div>
              <h3 className="font-semibold">HTTP 402 Response</h3>
              <p className="text-sm text-muted-foreground">
                Backend responds with payment required and displays dynamic USDC pricing
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-lg mb-3">
                <span className="text-xl font-bold">3</span>
              </div>
              <h3 className="font-semibold">Instant Unlock</h3>
              <p className="text-sm text-muted-foreground">
                Pay with USDC via MetaMask and instantly access the endpoint data
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mock Response Preview (if endpoint selected) */}
      {selectedEndpoint && (
        <Card>
          <CardHeader>
            <CardTitle>Preview: {selectedEndpoint.name}</CardTitle>
            <CardDescription>
              Sample response data (unlock to access real-time data)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted rounded-lg p-4">
              <pre className="text-sm overflow-x-auto">
                {JSON.stringify(selectedEndpoint.mockResponse, null, 2)}
              </pre>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setSelectedEndpoint(null)}>
              Close Preview
            </Button>
            <Button className="gap-2">
              Pay {selectedEndpoint.costPerCall} USDC & Unlock
              <ArrowRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
