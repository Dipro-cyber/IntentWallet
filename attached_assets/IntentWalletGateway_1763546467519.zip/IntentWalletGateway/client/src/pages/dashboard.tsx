import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, DollarSign, Zap, TrendingUp, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWeb3 } from "@/contexts/Web3Context";
import { Link } from "wouter";
import { WalletMetrics } from "@shared/schema";

export default function Dashboard() {
  const { address } = useWeb3();

  const { data: metrics, isLoading } = useQuery<WalletMetrics>({
    queryKey: ['/api/metrics', address],
    enabled: !!address,
  });

  // Show empty metrics when wallet not connected
  const displayMetrics = address && metrics ? metrics : {
    totalIntents: 0,
    totalApiCalls: 0,
    totalSpent: '0.00',
    activeSessions: 0,
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          {address
            ? "Welcome to your Base Intent Wallet. Execute intents, pay for API access, and track your activity."
            : "Connect your wallet to start executing pay-per-intent transactions and unlock API access."}
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Intents</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-3xl font-semibold" data-testid="metric-total-intents">
                  {displayMetrics.totalIntents}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Executed via smart wallet
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Calls Made</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-3xl font-semibold" data-testid="metric-api-calls">
                  {displayMetrics.totalApiCalls}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Across all endpoints
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-3xl font-semibold font-mono" data-testid="metric-total-spent">
                  {displayMetrics.totalSpent} <span className="text-lg">USDC</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  HTTP 402 payments
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Sessions</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-3xl font-semibold" data-testid="metric-active-sessions">
                  {displayMetrics.activeSessions}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Currently unlocked
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Create New Intent</CardTitle>
            <CardDescription>
              Compose natural language requests and execute them with pay-per-intent flows
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/intent">
              <Button className="w-full gap-2" data-testid="button-go-to-intent">
                Start New Intent
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Browse API Endpoints</CardTitle>
            <CardDescription>
              Explore available APIs and unlock access with HTTP 402 payments
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/api-access">
              <Button variant="outline" className="w-full gap-2" data-testid="button-go-to-api">
                View APIs
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Feature Overview */}
      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
          <CardDescription>
            ERC-4337 compatible smart wallet with HTTP 402 pay-per-use flows on Base L2
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                  1
                </div>
                <h3 className="font-semibold">Compose Intent</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Write natural language requests like "swap 2 ETH to USDC" or "query NFT mints"
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                  2
                </div>
                <h3 className="font-semibold">Pay with HTTP 402</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Approve dynamic USDC payment for API access or intent execution
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                  3
                </div>
                <h3 className="font-semibold">Execute & Access</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Smart contract validates payment and unlocks API endpoints or executes actions
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
