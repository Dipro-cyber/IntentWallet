import { useState } from "react";
import { useWeb3 } from "@/contexts/Web3Context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Sparkles, User, Bot, ArrowRight, Loader2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PaymentDialog } from "@/components/payment-dialog";
import { Intent, InsertIntent, UserType } from "@shared/schema";

const INTENT_EXAMPLES = {
  human: [
    "Swap 2 ETH to USDC with less than 0.5% slippage",
    "Query top NFT mints in the last hour on Base",
    "Get current price of ETH/USDC from oracle",
    "Execute DeFi swap on Aerodrome with MEV protection",
  ],
  agent: [
    "AUTO: Monitor ETH price and alert if drops below $2400",
    "AUTO: Execute arbitrage between BaseSwap and Aerodrome",
    "AUTO: Rebalance portfolio when BTC allocation exceeds 40%",
    "AUTO: Fetch Base protocol TVL data every 6 hours",
  ],
};

export default function IntentComposer() {
  const { address } = useWeb3();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [intentText, setIntentText] = useState("");
  const [isAgentMode, setIsAgentMode] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [pendingIntent, setPendingIntent] = useState<Intent | null>(null);

  const submitIntentMutation = useMutation({
    mutationFn: async (data: InsertIntent) => {
      const response = await apiRequest<Intent>('POST', '/api/intents', data);
      return response;
    },
    onSuccess: (intent) => {
      setPendingIntent(intent);
      setShowPaymentDialog(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Submit Intent",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!address) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to submit intents",
        variant: "destructive",
      });
      return;
    }

    if (!intentText.trim()) {
      toast({
        title: "Empty Intent",
        description: "Please enter an intent to execute",
        variant: "destructive",
      });
      return;
    }

    submitIntentMutation.mutate({
      userAddress: address,
      userType: isAgentMode ? "agent" : "human",
      rawIntent: intentText,
      parsedIntent: null,
      intentType: null,
      estimatedCost: null,
      status: "pending",
    });
  };

  const handlePaymentComplete = () => {
    setShowPaymentDialog(false);
    setIntentText("");
    setPendingIntent(null);
    queryClient.invalidateQueries({ queryKey: ['/api/intents'] });
    queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });

    toast({
      title: "Intent Executed Successfully",
      description: "Your intent has been processed and completed",
    });
  };

  if (!address) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="max-w-md text-center space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
            <Sparkles className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold">Connect Wallet to Start</h2>
          <p className="text-muted-foreground">
            Connect your Base wallet to compose and execute intents with pay-per-use API access.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Intent Composer</h1>
        <p className="text-muted-foreground">
          Write natural language requests and execute them with instant HTTP 402 payments
        </p>
      </div>

      {/* User Type Toggle */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isAgentMode ? (
                <Bot className="h-5 w-5 text-primary" />
              ) : (
                <User className="h-5 w-5 text-primary" />
              )}
              <div>
                <Label htmlFor="agent-mode" className="text-base font-medium cursor-pointer">
                  {isAgentMode ? "AI Agent Mode" : "Human User Mode"}
                </Label>
                <p className="text-sm text-muted-foreground">
                  {isAgentMode
                    ? "Autonomous agent operations with automatic execution"
                    : "Manual intent composition with user approval"}
                </p>
              </div>
            </div>
            <Switch
              id="agent-mode"
              checked={isAgentMode}
              onCheckedChange={setIsAgentMode}
              data-testid="switch-agent-mode"
            />
          </div>
        </CardContent>
      </Card>

      {/* Intent Input */}
      <Card>
        <CardHeader>
          <CardTitle>Compose Your Intent</CardTitle>
          <CardDescription>
            Describe what you want to do in natural language. Our parser will interpret and execute it.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder={
              isAgentMode
                ? 'e.g., "AUTO: Monitor ETH price and alert if drops below $2400"'
                : 'e.g., "Swap 2 ETH to USDC with less than 0.5% slippage"'
            }
            value={intentText}
            onChange={(e) => setIntentText(e.target.value)}
            className="min-h-32 resize-none"
            data-testid="input-intent-text"
          />

          {/* Suggestion Chips */}
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Suggested Intents:</Label>
            <div className="flex flex-wrap gap-2">
              {INTENT_EXAMPLES[isAgentMode ? "agent" : "human"].map((example, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover-elevate"
                  onClick={() => setIntentText(example)}
                  data-testid={`suggestion-${index}`}
                >
                  {example}
                </Badge>
              ))}
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!intentText.trim() || submitIntentMutation.isPending}
            className="w-full gap-2"
            size="lg"
            data-testid="button-submit-intent"
          >
            {submitIntentMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Processing Intent...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Submit Intent & Pay
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Intent Parsing Preview */}
      {intentText && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Intent Parsing Preview</CardTitle>
            <CardDescription>
              Mock LLM interpretation of your request
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Detected Action:</span>
              <Badge variant="secondary">
                {intentText.toLowerCase().includes('swap') ? 'DEX Swap' :
                 intentText.toLowerCase().includes('nft') ? 'NFT Query' :
                 intentText.toLowerCase().includes('price') || intentText.toLowerCase().includes('oracle') ? 'Price Oracle' :
                 'API Call'}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Estimated Cost:</span>
              <span className="font-mono font-semibold text-primary">
                {intentText.toLowerCase().includes('swap') ? '1.00' :
                 intentText.toLowerCase().includes('nft') ? '0.50' :
                 intentText.toLowerCase().includes('oracle') || intentText.toLowerCase().includes('price') ? '0.25' :
                 '0.75'} USDC
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              Payment will be processed via HTTP 402 protocol after submission
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment Dialog */}
      {pendingIntent && (
        <PaymentDialog
          open={showPaymentDialog}
          onClose={() => setShowPaymentDialog(false)}
          intent={pendingIntent}
          onPaymentComplete={handlePaymentComplete}
        />
      )}
    </div>
  );
}
