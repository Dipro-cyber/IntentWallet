import { useQuery } from "@tanstack/react-query";
import { useWeb3 } from "@/contexts/Web3Context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { History, ExternalLink, FileText, Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";
import { Intent, Payment } from "@shared/schema";
import { formatDistance } from "date-fns";

interface IntentWithPayment extends Intent {
  payment?: Payment;
}

export default function PaymentHistory() {
  const { address } = useWeb3();

  const { data: intents, isLoading } = useQuery<IntentWithPayment[]>({
    queryKey: ['/api/intents', address],
    enabled: !!address,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-destructive" />;
      case "processing":
        return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case "confirmed":
        return "default";
      case "failed":
        return "destructive";
      case "processing":
        return "secondary";
      default:
        return "outline";
    }
  };

  if (!address) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="max-w-md text-center space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
            <History className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold">Connect Wallet</h2>
          <p className="text-muted-foreground">
            Connect your wallet to view your payment history and transaction records.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-semibold mb-2">Payment History</h1>
        <p className="text-muted-foreground">
          View all your HTTP 402 payments and intent execution history
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>
            All intents executed and payments processed through your smart wallet
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !intents || intents.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Payment History</h3>
              <p className="text-sm text-muted-foreground mb-4">
                You haven't executed any intents yet. Start by composing your first intent.
              </p>
              <Button asChild>
                <a href="/intent">Create New Intent</a>
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Intent / Action</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Proof</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {intents.map((intent) => (
                  <TableRow key={intent.id} data-testid={`transaction-row-${intent.id}`}>
                    <TableCell className="text-sm text-muted-foreground">
                      {intent.createdAt
                        ? formatDistance(new Date(intent.createdAt), new Date(), {
                            addSuffix: true,
                          })
                        : 'Recently'}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium line-clamp-1">
                          {intent.rawIntent}
                        </div>
                        {intent.intentType && (
                          <Badge variant="outline" className="text-xs">
                            {intent.intentType}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono font-semibold">
                      {intent.payment?.amount || intent.estimatedCost || '0.00'} USDC
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(intent.status)}
                        <Badge variant={getStatusVariant(intent.status)}>
                          {intent.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {intent.payment?.txHash && (
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          data-testid={`button-view-proof-${intent.id}`}
                        >
                          <a
                            href={`https://basescan.org/tx/${intent.payment.txHash}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="gap-1"
                          >
                            View Proof
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
