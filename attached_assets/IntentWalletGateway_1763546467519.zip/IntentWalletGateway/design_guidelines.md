# Design Guidelines: Advanced Web3 Wallet & HTTP 402 API Gateway

## Design Approach

**Selected Framework**: Material Design principles combined with Linear's professional aesthetic and modern Web3 dashboard patterns (Uniswap, Rainbow Wallet)

**Rationale**: This utility-focused, information-dense application requires clear feedback systems, structured hierarchy, and professional polish. Material Design's component patterns excel at complex state management (pending transactions, payment flows), while Linear's minimalism ensures the technical complexity doesn't overwhelm users.

## Core Design Principles

1. **Transparency First**: Every transaction, payment, and API call shows clear status, cost, and confirmation
2. **Progressive Disclosure**: Complex features (intent parsing, cross-chain routing) revealed contextually
3. **Dual Interface**: Distinct but cohesive flows for human users vs. AI agents
4. **Trust Signals**: Prominent security indicators, wallet balances, and transaction proofs

## Typography System

**Font Stack**: Inter for UI (Google Fonts CDN)
- **Display**: text-4xl to text-6xl, font-semibold for dashboard headers
- **Section Titles**: text-2xl, font-semibold
- **Body**: text-base, font-normal for descriptions
- **Labels**: text-sm, font-medium for form fields, card metadata
- **Monospace**: Use `font-mono` for addresses, transaction hashes, amounts (0x..., USDC values)
- **Micro-copy**: text-xs for helper text, status badges

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16, 24
- **Component padding**: p-4 to p-6 for cards
- **Section spacing**: py-12 to py-16 for dashboard sections
- **Grid gaps**: gap-4 to gap-6 for card grids
- **Form field spacing**: space-y-4

**Container Strategy**:
- Full-width dashboard with max-w-7xl centered wrapper
- Two-column layout for main view: Sidebar (w-64 fixed) + Main content area (flex-1)
- Three-column grid for feature cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)

## Component Library

### Navigation & Layout

**Top Header Bar**:
- Full-width, h-16, sticky with backdrop-blur
- Left: Logo + App name
- Center: Network indicator (Base L2 badge), wallet balance display
- Right: Wallet connection button, user menu

**Sidebar Navigation** (Desktop only, drawer on mobile):
- Fixed w-64, full-height
- Navigation items: Dashboard, New Intent, Payment History, API Access, Analytics, Settings
- Bottom section: Network status, documentation link

### Core Dashboard Components

**Intent Composer** (Primary Feature):
- Large textarea (min-h-48) for natural language input
- Auto-suggest chips below for common intents ("Swap ETH→USDC", "Query NFT mints", "Access price oracle")
- Real-time intent parsing preview card showing interpreted action
- Pricing display: Shows dynamic USDC cost before submission
- Primary action button: "Submit Intent & Pay"

**HTTP 402 Payment Dialog**:
- Modal overlay with backdrop-blur
- Clear cost breakdown (API endpoint cost, gas estimate, total in USDC)
- Payment method selector (connected wallet pre-selected)
- Two-step confirmation: "Authorize Payment" → "Confirm Transaction"
- Live status indicator during payment processing
- Success state with transaction hash link

**Transaction Status Cards**:
- Card-based timeline showing: Pending → Processing → Confirmed
- Each card includes: timestamp, intent description, cost paid, status badge
- Expandable details: transaction hash, block number, gas used
- Color-coded status badges (avoid color names, use border treatments)

**Access History Grid**:
- Table layout with columns: Timestamp, Intent/Action, Cost, Status, Proof
- Filterable by date range, action type
- "View Proof" button linking to on-chain verification

### Forms & Inputs

**Standard Input Field**:
- h-12, rounded-lg borders
- Clear label above (text-sm, font-medium)
- Placeholder text for guidance
- Helper text below for format examples (e.g., "e.g., 0x742d...")
- Focus state with ring treatment

**Amount Input** (for USDC/ETH):
- Large text-2xl display for entered amount
- Currency selector dropdown
- Balance display: "Available: X.XX USDC"
- Max button for quick fills

**Wallet Connection Button**:
- Prominent in header when disconnected (h-10, px-6)
- Shows truncated address when connected (0x7a2...f8c)
- Dropdown menu: View Balance, Disconnect, Copy Address

### Data Display

**Analytics Dashboard Cards**:
- Grid of metric cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Each card: Large number (text-3xl), label below, change indicator
- Metrics: Total Intents, API Calls Made, Total Spent, Active Sessions

**Live API Response Display**:
- Code block with syntax highlighting (use highlight.js via CDN)
- Copy button in top-right corner
- Timestamp of data fetch
- Refresh indicator when auto-updating

**Agent vs. Human User Indicator**:
- Top-right badge in intent composer
- Toggle switch to simulate agent mode (for demo)
- Different placeholder examples based on mode

### Interactive Elements

**Primary Buttons**:
- h-12, px-8, rounded-lg
- Font-semibold, text-base
- Used for: Submit Intent, Confirm Payment, Connect Wallet

**Secondary Buttons**:
- h-10, px-6, rounded-lg, border-2
- Used for: Cancel, View Details, Export

**Icon Buttons**:
- w-10 h-10, rounded-lg
- Used for: Refresh, Copy, Settings
- Icons: Heroicons (via CDN)

**Status Badges**:
- Inline-block, px-3, py-1, rounded-full, text-xs font-medium
- States: Pending, Processing, Confirmed, Failed, Unlocked
- Displayed inline with transaction items

### Feedback & States

**Loading States**:
- Skeleton loaders for card grids (animate-pulse)
- Spinner for in-progress transactions (w-5 h-5, animate-spin)
- Progress bars for multi-step flows (h-2, rounded-full)

**Empty States**:
- Centered icon (w-16 h-16) from Heroicons
- Heading: text-xl, font-semibold
- Description text-sm below
- Call-to-action button
- Examples: "No payment history yet", "No API access purchased"

**Error States**:
- Alert card with icon, message, action button
- Inline field validation errors (text-sm below input)

## Icons

**Library**: Heroicons (via CDN)
- Navigation: home, document-text, clock, key, chart-bar, cog
- Actions: arrow-up-right, clipboard-copy, refresh, check-circle
- Status: clock (pending), arrow-path (processing), check-badge (confirmed)

## Images

**Hero Section**: No traditional hero image. This is a dashboard application.

**Supporting Visuals**:
- Network logo badges (Base L2 logo in header, 24x24)
- Wallet provider icons (MetaMask, Coinbase Wallet) in connection flow (32x32)
- Empty state illustrations (simple line art, 200x200) for no-data scenarios

## Animations

**Minimal, Purposeful Only**:
- Smooth transitions on modal open/close (transition-all duration-300)
- Status badge color transitions (transition-colors duration-200)
- Loading spinners for async operations
- NO scroll animations, parallax, or decorative motion

## Accessibility

- All interactive elements have clear focus states (ring-2 ring-offset-2)
- Form inputs paired with labels (htmlFor/id)
- Status communicated via text + visual indicators (not color alone)
- Keyboard navigation throughout (Tab order logical)
- ARIA labels on icon-only buttons

## Responsive Behavior

**Desktop (lg+)**: Two-column layout with fixed sidebar
**Tablet (md)**: Collapsible sidebar, two-column card grids
**Mobile (base)**: Drawer navigation, single-column cards, stacked forms, touch-friendly h-12 buttons

This design creates a professional, trust-inspiring Web3 application that balances technical sophistication with user clarity, ensuring both human users and AI agents can execute pay-per-intent flows seamlessly.