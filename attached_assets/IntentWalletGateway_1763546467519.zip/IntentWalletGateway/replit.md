# Base Intent Wallet - Pay-Per-Intent Web3 Gateway

## Overview

This is an advanced Web3 decentralized application (dApp) built for the Base L2 network that implements a pay-per-intent smart contract wallet with HTTP 402 payment flows. The application enables both human users and autonomous AI agents to execute blockchain intents (swaps, NFT queries, oracle calls, DeFi actions) through natural language input, with seamless USDC-based micropayments for API access and transaction execution.

The system demonstrates modern Web3 UX patterns combining ERC-4337 account abstraction concepts with pay-per-use API gateway architecture, where users pay only for the specific actions they execute rather than upfront subscriptions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript, built using Vite for fast development and optimized production builds.

**UI Component System**: 
- Shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for styling with custom design tokens following Material Design and Linear aesthetic principles
- New York style variant with neutral color scheme
- Responsive design supporting desktop and mobile viewports

**State Management**:
- TanStack Query (React Query) for server state management and API caching
- React Context API for wallet connection state (Web3Context) and theme state (ThemeProvider)
- No global state management library - relies on component-local state and query cache

**Routing**: Wouter for lightweight client-side routing with the following pages:
- Dashboard: Overview of wallet metrics and activity
- Intent Composer: Main interface for submitting natural language intents
- Payment History: Transaction and payment records
- API Access: Browse and purchase access to API endpoints
- Analytics: Usage insights and spending patterns

**Key Design Decisions**:
- Sidebar navigation pattern with mobile drawer variant
- Progressive disclosure for complex features (intent parsing, payment flows)
- Dual interface support: Human users can write natural language intents; agent mode for automated actions
- Material Design typography system using Inter font family with JetBrains Mono for monospace (addresses, hashes)

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript

**API Design**:
- RESTful JSON API with endpoints under `/api/*` prefix
- Intent management: POST/GET operations for creating and retrieving intents by user address
- Payment tracking: Payment record creation and confirmation flows
- Metrics endpoints: Aggregated wallet statistics

**Storage Layer**:
- In-memory storage implementation (`MemStorage` class) for development/demo
- Designed for extensibility to PostgreSQL via Drizzle ORM (schema defined, migrations configured)
- Schema supports: Intents, Payments, API Access Records, Wallet Metrics

**HTTP 402 Payment Flow**:
- Middleware architecture supports payment requirement checks (currently disabled for MVP demo)
- Production-ready structure for on-chain payment proof verification before granting API access
- Payment status tracking: required → pending → confirmed → failed

**Schema Design Rationale**:
- Intents table: Stores raw natural language input, parsed structured data (JSONB), cost estimates, and status
- Payments table: Links to intents, tracks USDC amounts, transaction hashes, block confirmations, on-chain proof hashes
- User type differentiation: "human" vs "agent" for different UX flows and analytics
- Transaction status enum: pending → processing → confirmed → failed

### Web3 Integration Layer

**Wallet Connection**:
- MetaMask integration via ethers.js v6 BrowserProvider
- Base L2 network targeting (Chain ID 8453 mainnet, 84532 testnet)
- Connection state management: address, balance, chainId, loading states

**Smart Contract Integration** (Designed, not yet implemented):
- ERC-4337 compatible account abstraction wallet concept
- Intent execution: Translates parsed intents into contract calls or multi-step actions
- Payment verification: On-chain USDC payment proofs before unlocking access
- Mock transaction simulation for demo purposes (generates fake tx hashes)

**Key Web3 Decisions**:
- Chose ethers.js over web3.js for better TypeScript support and cleaner API
- Base L2 network selection for lower gas costs and faster confirmations
- USDC as payment token for stable pricing and better UX than volatile ETH
- Account abstraction approach enables gasless transactions and batch operations

### Data Models

**Intent Types**: swap, nft_query, price_oracle, analytics, api_call, defi_action

**Payment Flow States**: 
1. User submits intent → estimated cost calculated
2. Payment dialog opens → user authorizes
3. Mock transaction sent → payment record created as "pending"
4. Simulated confirmation → payment marked "confirmed" with tx hash and proof
5. Intent status updated to "confirmed" → API access granted

**Database Schema** (PostgreSQL via Drizzle ORM):
- UUIDs for primary keys
- Decimal fields for precise USDC amounts (18 digits, 6 decimal places)
- JSONB for flexible parsed intent storage
- Timestamps for audit trails
- Enum-like text fields with TypeScript type safety via Zod schemas

### Build and Development

**Development Mode**:
- Vite dev server with HMR for frontend
- tsx for running TypeScript server directly
- Concurrent frontend/backend development
- Replit-specific plugins for error overlay and dev tools

**Production Build**:
- Vite bundles frontend to `dist/public`
- esbuild bundles backend to `dist/index.js` as ESM module
- Single production server serves static assets and API

**Type Safety**:
- Shared schema definitions between client and server (`@shared/schema`)
- Zod for runtime validation and TypeScript type inference
- Drizzle-Zod integration for type-safe database operations

## External Dependencies

### Third-Party UI Libraries
- **Radix UI**: Headless component primitives for accessible UI components (dialogs, dropdowns, tooltips, etc.)
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Type-safe component variant management
- **cmdk**: Command palette component

### Web3 & Blockchain
- **ethers.js**: Ethereum library for wallet connection and contract interaction
- **Base L2 Network**: Target blockchain (requires MetaMask or compatible wallet)

### Database & ORM
- **Drizzle ORM**: TypeScript-first ORM for PostgreSQL
- **@neondatabase/serverless**: Serverless Postgres driver (configured for future use)
- **Drizzle Kit**: Migration management and schema push tooling

### State Management & Data Fetching
- **TanStack Query**: Async state management, caching, and server synchronization
- **React Hook Form**: Form state management with validation
- **Zod**: Schema validation and type inference

### Styling
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS & Autoprefixer**: CSS processing pipeline
- **Google Fonts**: Inter (UI text) and JetBrains Mono (monospace)

### Development Tools
- **Vite**: Frontend build tool and dev server
- **TypeScript**: Type safety across the stack
- **tsx**: TypeScript execution for server
- **esbuild**: Fast JavaScript bundler for production backend
- **Replit Plugins**: Development experience enhancements (error modal, cartographer, dev banner)

### Date/Time Utilities
- **date-fns**: Date formatting and manipulation (e.g., "2 hours ago" relative time displays)

### Session Management (Configured)
- **connect-pg-simple**: PostgreSQL session store for Express (future authentication)
- **express-session**: Session middleware (not yet implemented)

### Notes on Future Integrations
- Smart contract deployment tooling (Hardhat/Foundry) not yet integrated
- LLM API for actual intent parsing (currently mocked)
- Cross-chain routing protocols (not implemented)
- MEV protection services (architecture supports, not integrated)
- Real price oracles (mocked endpoints currently)