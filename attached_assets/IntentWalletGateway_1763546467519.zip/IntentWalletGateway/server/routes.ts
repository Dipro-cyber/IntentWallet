import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertIntentSchema, insertPaymentSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Middleware for validating wallet addresses
  const validateAddress = (address: string): boolean => {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  };

  // HTTP 402 Middleware - for demo purposes, this is disabled but can be enabled
  // In production, this would verify on-chain payment proofs before granting access
  const requirePayment = (req: any, res: any, next: any) => {
    // For MVP demo, allow all requests to pass through
    // In production, you would check for valid payment proof here
    next();
  };

  // ============== Intent Endpoints ==============

  // Create new intent
  app.post('/api/intents', async (req, res) => {
    try {
      const validatedData = insertIntentSchema.parse(req.body);
      
      if (!validateAddress(validatedData.userAddress)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      const intent = await storage.createIntent(validatedData);
      
      res.status(201).json(intent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Validation error', details: error.errors });
      }
      console.error('Error creating intent:', error);
      res.status(500).json({ error: 'Failed to create intent' });
    }
  });

  // Get intents by user address
  app.get('/api/intents/:address', async (req, res) => {
    try {
      const { address } = req.params;
      
      if (!validateAddress(address)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      const intents = await storage.getIntentsByAddress(address);
      
      // Enrich intents with payment data
      const enrichedIntents = await Promise.all(
        intents.map(async (intent) => {
          const payments = await storage.getPaymentsByAddress(address);
          const payment = payments.find(p => p.intentId === intent.id);
          return { ...intent, payment };
        })
      );
      
      res.json(enrichedIntents);
    } catch (error) {
      console.error('Error fetching intents:', error);
      res.status(500).json({ error: 'Failed to fetch intents' });
    }
  });

  // Update intent status
  app.patch('/api/intents/:id/status', async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!status || !['pending', 'processing', 'confirmed', 'failed'].includes(status)) {
        return res.status(400).json({ error: 'Invalid status' });
      }

      const intent = await storage.updateIntentStatus(id, status);
      
      if (!intent) {
        return res.status(404).json({ error: 'Intent not found' });
      }

      res.json(intent);
    } catch (error) {
      console.error('Error updating intent:', error);
      res.status(500).json({ error: 'Failed to update intent' });
    }
  });

  // ============== Payment Endpoints ==============

  // Create new payment
  app.post('/api/payments', async (req, res) => {
    try {
      const validatedData = insertPaymentSchema.parse(req.body);
      
      if (!validateAddress(validatedData.userAddress)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      // Verify intent exists
      const intent = await storage.getIntent(validatedData.intentId);
      if (!intent) {
        return res.status(404).json({ error: 'Intent not found' });
      }

      const payment = await storage.createPayment(validatedData);
      
      // Update intent status to processing
      await storage.updateIntentStatus(validatedData.intentId, 'processing');
      
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Validation error', details: error.errors });
      }
      console.error('Error creating payment:', error);
      res.status(500).json({ error: 'Failed to create payment' });
    }
  });

  // Confirm payment (simulate on-chain confirmation)
  app.patch('/api/payments/:id/confirm', async (req, res) => {
    try {
      const { id } = req.params;
      const { txHash, blockNumber, gasUsed, proofHash } = req.body;

      if (!txHash) {
        return res.status(400).json({ error: 'Transaction hash is required' });
      }

      // Store proof fields exactly as provided (preserving null for missing data)
      const payment = await storage.confirmPayment(
        id,
        txHash,
        blockNumber || null,
        gasUsed || null,
        proofHash || null
      );

      if (!payment) {
        return res.status(404).json({ error: 'Payment not found' });
      }

      // Create API access record to track unlocked access
      await storage.createApiAccessRecord({
        intentId: payment.intentId,
        paymentId: payment.id,
        userAddress: payment.userAddress,
        endpoint: '/api/intents',
        accessGranted: true,
        responseData: null,
        expiresAt: null,
      });

      res.json(payment);
    } catch (error) {
      console.error('Error confirming payment:', error);
      res.status(500).json({ error: 'Failed to confirm payment' });
    }
  });

  // Get payments by address
  app.get('/api/payments/:address', async (req, res) => {
    try {
      const { address } = req.params;
      
      if (!validateAddress(address)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      const payments = await storage.getPaymentsByAddress(address);
      res.json(payments);
    } catch (error) {
      console.error('Error fetching payments:', error);
      res.status(500).json({ error: 'Failed to fetch payments' });
    }
  });

  // ============== Metrics & Analytics ==============

  // Get wallet metrics
  app.get('/api/metrics/:address', async (req, res) => {
    try {
      const { address } = req.params;
      
      if (!validateAddress(address)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      const metrics = await storage.getWalletMetrics(address);
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching metrics:', error);
      res.status(500).json({ error: 'Failed to fetch metrics' });
    }
  });

  // Get analytics data
  app.get('/api/analytics/:address', async (req, res) => {
    try {
      const { address } = req.params;
      
      if (!validateAddress(address)) {
        return res.status(400).json({ error: 'Invalid wallet address' });
      }

      const intents = await storage.getIntentsByAddress(address);
      const payments = await storage.getPaymentsByAddress(address);
      const apiRecords = await storage.getApiAccessRecordsByAddress(address);

      // Build recent activity
      const recentActivity = intents.slice(0, 10).map(intent => ({
        type: 'intent' as const,
        timestamp: intent.createdAt,
        description: intent.rawIntent,
      }));

      res.json({
        intents,
        payments,
        recentActivity,
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
      res.status(500).json({ error: 'Failed to fetch analytics' });
    }
  });

  // ============== Mock API Endpoints (HTTP 402 Protected) ==============

  // HTTP 402 Demo Endpoint - showcases the payment required flow
  app.get('/api/http402-demo', (req, res) => {
    const { access_token } = req.query;
    
    if (!access_token) {
      // Return HTTP 402 Payment Required
      return res.status(402).json({
        error: 'Payment Required',
        message: 'This API endpoint requires payment to access',
        cost: '0.50 USDC',
        paymentMethods: ['USDC', 'ETH'],
        instructions: 'Submit an intent to receive an access token after payment',
      });
    }
    
    // Access granted
    res.json({
      success: true,
      message: 'Access granted via HTTP 402 payment',
      data: { example: 'This is premium data unlocked after payment' },
    });
  });

  // NFT Mint Tracker - requires payment
  app.get('/api/nft-mints', requirePayment, async (req, res) => {
    res.json({
      success: true,
      data: {
        mints: [
          { collection: 'Base Gods', volume: '125.5 ETH', mints: 1247, floor: '0.08 ETH' },
          { collection: 'Onchain Summer', volume: '89.2 ETH', mints: 892, floor: '0.05 ETH' },
          { collection: 'Base Builders', volume: '67.8 ETH', mints: 678, floor: '0.10 ETH' },
        ],
        timestamp: new Date().toISOString(),
      },
    });
  });

  // Price Oracle - requires payment
  app.get('/api/price-oracle', requirePayment, async (req, res) => {
    const { pair = 'ETH/USDC' } = req.query;
    
    res.json({
      success: true,
      data: {
        pair,
        price: '2456.78',
        timestamp: Date.now(),
        source: 'Chainlink',
        confidence: 0.99,
      },
    });
  });

  // DeFi Analytics - requires payment
  app.get('/api/defi-analytics', requirePayment, async (req, res) => {
    res.json({
      success: true,
      data: {
        protocols: [
          { name: 'Aerodrome', tvl: '$245M', apy: '12.5%', volume24h: '$45M' },
          { name: 'BaseSwap', tvl: '$89M', apy: '8.2%', volume24h: '$23M' },
          { name: 'Moonwell', tvl: '$156M', apy: '6.8%', volume24h: '$18M' },
        ],
        totalTVL: '$490M',
        timestamp: new Date().toISOString(),
      },
    });
  });

  // Swap Executor - requires payment and simulates execution
  app.post('/api/swap-execute', requirePayment, async (req, res) => {
    const { fromToken, toToken, amount } = req.body;
    
    // Simulate swap execution delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    res.json({
      success: true,
      data: {
        txHash: '0x' + Array.from({ length: 64 }, () => 
          Math.floor(Math.random() * 16).toString(16)
        ).join(''),
        fromToken,
        toToken,
        amountIn: amount,
        amountOut: (parseFloat(amount) * 2456.78).toFixed(2),
        slippage: '0.35%',
        gasUsed: '145000',
      },
    });
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        storage: 'operational',
        web3: 'operational',
        http402: 'operational',
      },
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
