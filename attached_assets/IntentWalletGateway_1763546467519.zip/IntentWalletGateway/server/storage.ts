import {
  type Intent,
  type InsertIntent,
  type Payment,
  type InsertPayment,
  type ApiAccessRecord,
  type InsertApiAccessRecord,
  type WalletMetrics,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Intent operations
  createIntent(intent: InsertIntent): Promise<Intent>;
  getIntent(id: string): Promise<Intent | undefined>;
  getIntentsByAddress(address: string): Promise<Intent[]>;
  updateIntentStatus(id: string, status: string): Promise<Intent | undefined>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayment(id: string): Promise<Payment | undefined>;
  getPaymentsByAddress(address: string): Promise<Payment[]>;
  confirmPayment(
    id: string,
    txHash: string,
    blockNumber: string,
    gasUsed: string,
    proofHash: string
  ): Promise<Payment | undefined>;

  // API Access operations
  createApiAccessRecord(record: InsertApiAccessRecord): Promise<ApiAccessRecord>;
  getApiAccessRecordsByAddress(address: string): Promise<ApiAccessRecord[]>;

  // Metrics
  getWalletMetrics(address: string): Promise<WalletMetrics>;
}

export class MemStorage implements IStorage {
  private intents: Map<string, Intent>;
  private payments: Map<string, Payment>;
  private apiAccessRecords: Map<string, ApiAccessRecord>;

  constructor() {
    this.intents = new Map();
    this.payments = new Map();
    this.apiAccessRecords = new Map();
  }

  // Intent operations
  async createIntent(insertIntent: InsertIntent): Promise<Intent> {
    const id = randomUUID();
    const now = new Date();
    
    // Mock intent parsing - simple logic to estimate cost and type
    let intentType = insertIntent.intentType;
    let estimatedCost = insertIntent.estimatedCost;

    if (!intentType || !estimatedCost) {
      const rawLower = insertIntent.rawIntent.toLowerCase();
      if (rawLower.includes('swap')) {
        intentType = 'swap';
        estimatedCost = '1.00';
      } else if (rawLower.includes('nft')) {
        intentType = 'nft_query';
        estimatedCost = '0.50';
      } else if (rawLower.includes('price') || rawLower.includes('oracle')) {
        intentType = 'price_oracle';
        estimatedCost = '0.25';
      } else if (rawLower.includes('defi') || rawLower.includes('tvl')) {
        intentType = 'analytics';
        estimatedCost = '0.75';
      } else {
        intentType = 'api_call';
        estimatedCost = '0.50';
      }
    }

    const intent: Intent = {
      ...insertIntent,
      id,
      intentType,
      estimatedCost,
      createdAt: now,
      updatedAt: now,
    };

    this.intents.set(id, intent);
    return intent;
  }

  async getIntent(id: string): Promise<Intent | undefined> {
    return this.intents.get(id);
  }

  async getIntentsByAddress(address: string): Promise<Intent[]> {
    return Array.from(this.intents.values())
      .filter((intent) => intent.userAddress.toLowerCase() === address.toLowerCase())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async updateIntentStatus(id: string, status: string): Promise<Intent | undefined> {
    const intent = this.intents.get(id);
    if (!intent) return undefined;

    const updated = { ...intent, status, updatedAt: new Date() };
    this.intents.set(id, updated);
    return updated;
  }

  // Payment operations
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = randomUUID();
    const payment: Payment = {
      intentId: insertPayment.intentId,
      userAddress: insertPayment.userAddress,
      amount: insertPayment.amount,
      currency: insertPayment.currency || 'USDC',
      paymentStatus: insertPayment.paymentStatus || 'pending',
      // Store optional fields as-is (null if not provided)
      txHash: insertPayment.txHash ?? null,
      blockNumber: insertPayment.blockNumber ?? null,
      gasUsed: insertPayment.gasUsed ?? null,
      proofHash: insertPayment.proofHash ?? null,
      id,
      createdAt: new Date(),
      confirmedAt: null,
    };

    this.payments.set(id, payment);
    return payment;
  }

  async getPayment(id: string): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async getPaymentsByAddress(address: string): Promise<Payment[]> {
    return Array.from(this.payments.values())
      .filter((payment) => payment.userAddress.toLowerCase() === address.toLowerCase())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async confirmPayment(
    id: string,
    txHash: string,
    blockNumber: string | null,
    gasUsed: string | null,
    proofHash: string | null
  ): Promise<Payment | undefined> {
    const payment = this.payments.get(id);
    if (!payment) return undefined;

    const confirmed: Payment = {
      ...payment,
      paymentStatus: 'confirmed',
      txHash,
      blockNumber,
      gasUsed,
      proofHash,
      confirmedAt: new Date(),
    };

    this.payments.set(id, confirmed);

    // Also update the associated intent status
    await this.updateIntentStatus(payment.intentId, 'confirmed');

    return confirmed;
  }

  // API Access operations
  async createApiAccessRecord(
    insertRecord: InsertApiAccessRecord
  ): Promise<ApiAccessRecord> {
    const id = randomUUID();
    const record: ApiAccessRecord = {
      ...insertRecord,
      id,
      accessedAt: new Date(),
    };

    this.apiAccessRecords.set(id, record);
    return record;
  }

  async getApiAccessRecordsByAddress(address: string): Promise<ApiAccessRecord[]> {
    return Array.from(this.apiAccessRecords.values())
      .filter((record) => record.userAddress.toLowerCase() === address.toLowerCase())
      .sort((a, b) => new Date(b.accessedAt).getTime() - new Date(a.accessedAt).getTime());
  }

  // Metrics
  async getWalletMetrics(address: string): Promise<WalletMetrics> {
    const intents = await this.getIntentsByAddress(address);
    const payments = await this.getPaymentsByAddress(address);
    const apiRecords = await this.getApiAccessRecordsByAddress(address);

    const totalSpent = payments
      .filter((p) => p.paymentStatus === 'confirmed')
      .reduce((sum, p) => sum + parseFloat(p.amount || '0'), 0)
      .toFixed(2);

    const activeSessions = apiRecords.filter((r) => r.accessGranted).length;

    const lastIntent = intents[0];

    return {
      totalIntents: intents.length,
      totalApiCalls: apiRecords.length,
      totalSpent,
      activeSessions,
      lastActivity: lastIntent?.createdAt,
    };
  }
}

export const storage = new MemStorage();
