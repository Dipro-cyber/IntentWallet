import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Intent Types
export const intentTypes = ["swap", "nft_query", "price_oracle", "analytics", "api_call", "defi_action"] as const;
export type IntentType = typeof intentTypes[number];

// Transaction Status
export const transactionStatuses = ["pending", "processing", "confirmed", "failed"] as const;
export type TransactionStatus = typeof transactionStatuses[number];

// Payment Status
export const paymentStatuses = ["required", "pending", "confirmed", "failed"] as const;
export type PaymentStatus = typeof paymentStatuses[number];

// User Type (human vs agent)
export const userTypes = ["human", "agent"] as const;
export type UserType = typeof userTypes[number];

// Intents - user/agent requests that need to be processed
export const intents = pgTable("intents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userAddress: text("user_address").notNull(),
  userType: text("user_type").notNull().$type<UserType>(),
  rawIntent: text("raw_intent").notNull(), // Natural language input
  parsedIntent: jsonb("parsed_intent"), // Structured interpretation
  intentType: text("intent_type").$type<IntentType>(),
  estimatedCost: decimal("estimated_cost", { precision: 18, scale: 6 }), // USDC cost
  status: text("status").notNull().$type<TransactionStatus>().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertIntentSchema = createInsertSchema(intents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertIntent = z.infer<typeof insertIntentSchema>;
export type Intent = typeof intents.$inferSelect;

// Payments - HTTP 402 payment records
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  intentId: varchar("intent_id").notNull(),
  userAddress: text("user_address").notNull(),
  amount: decimal("amount", { precision: 18, scale: 6 }).notNull(), // USDC amount
  currency: text("currency").notNull().default("USDC"),
  paymentStatus: text("payment_status").notNull().$type<PaymentStatus>().default("required"),
  txHash: text("tx_hash"), // On-chain transaction hash
  blockNumber: text("block_number"),
  gasUsed: text("gas_used"),
  proofHash: text("proof_hash"), // On-chain proof of access
  createdAt: timestamp("created_at").defaultNow().notNull(),
  confirmedAt: timestamp("confirmed_at"),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  confirmedAt: true,
}).extend({
  // Make all proof/transaction fields nullable and optional for payment creation
  txHash: z.string().nullish(),
  blockNumber: z.string().nullish(),
  gasUsed: z.string().nullish(),
  proofHash: z.string().nullish(),
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

// API Access Records - tracking unlocked endpoints
export const apiAccessRecords = pgTable("api_access_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  intentId: varchar("intent_id").notNull(),
  paymentId: varchar("payment_id").notNull(),
  userAddress: text("user_address").notNull(),
  endpoint: text("endpoint").notNull(),
  accessGranted: boolean("access_granted").notNull().default(false),
  responseData: jsonb("response_data"),
  accessedAt: timestamp("accessed_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"), // Optional expiry for time-limited access
});

export const insertApiAccessRecordSchema = createInsertSchema(apiAccessRecords).omit({
  id: true,
  accessedAt: true,
});

export type InsertApiAccessRecord = z.infer<typeof insertApiAccessRecordSchema>;
export type ApiAccessRecord = typeof apiAccessRecords.$inferSelect;

// Analytics/Metrics - aggregate data
export interface WalletMetrics {
  totalIntents: number;
  totalApiCalls: number;
  totalSpent: string; // USDC amount as string
  activeSessions: number;
  lastActivity?: Date;
}

// Parsed Intent Structure
export interface ParsedIntentData {
  action: string;
  parameters: Record<string, unknown>;
  requiredApprovals?: string[];
  estimatedGas?: string;
}

// API Endpoint Configuration
export interface ApiEndpoint {
  id: string;
  name: string;
  description: string;
  costPerCall: string; // USDC
  category: "nft" | "defi" | "oracle" | "analytics";
  mockResponse?: unknown;
}

// Mock API Endpoints for Demo
export const mockApiEndpoints: ApiEndpoint[] = [
  {
    id: "nft_mint_tracker",
    name: "NFT Mint Tracker",
    description: "Get top NFT mints in the last hour on Base",
    costPerCall: "0.50",
    category: "nft",
    mockResponse: {
      mints: [
        { collection: "Base Gods", volume: "125.5 ETH", mints: 1247 },
        { collection: "Onchain Summer", volume: "89.2 ETH", mints: 892 },
      ]
    }
  },
  {
    id: "price_oracle",
    name: "Real-time Price Oracle",
    description: "Access live price feeds for ETH/USDC pairs",
    costPerCall: "0.25",
    category: "oracle",
    mockResponse: {
      pair: "ETH/USDC",
      price: "2456.78",
      timestamp: Date.now(),
      source: "Chainlink"
    }
  },
  {
    id: "defi_analytics",
    name: "DeFi Protocol Analytics",
    description: "Query TVL, APY, and volume data across Base protocols",
    costPerCall: "0.75",
    category: "analytics",
    mockResponse: {
      protocols: [
        { name: "Aerodrome", tvl: "245M", apy: "12.5%" },
        { name: "BaseSwap", tvl: "89M", apy: "8.2%" },
      ]
    }
  },
  {
    id: "swap_executor",
    name: "DEX Swap Executor",
    description: "Execute token swaps with MEV protection",
    costPerCall: "1.00",
    category: "defi",
    mockResponse: {
      success: true,
      txHash: "0x1234...5678",
      amountOut: "2456.78 USDC"
    }
  }
];
